@file:JvmName("LeapYear")

package logic

// TODO Implement the function
fun leapYear(year: Int): Boolean = true
