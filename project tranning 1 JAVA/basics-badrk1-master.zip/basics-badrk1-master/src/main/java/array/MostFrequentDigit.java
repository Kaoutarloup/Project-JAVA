package array;

public class MostFrequentDigit {

    public static int getMostFrequentDigit(String digitString) {
    	Character mostFreqDig=null;
		int mostFreqocc=0;
		for(int i=0;i<digitString.length();i++)

	{if(occurence(digitString.charAt(i),digitString)==mostFreqocc)
			mostFreqDig = (mostFreqDig < digitString.charAt(i)) 
			? mostFreqDig : digitString.charAt(i);
		if(occurence(digitString.charAt(i),digitString)>mostFreqocc)
		{
			mostFreqocc=occurence(digitString.charAt(i),digitString);
			mostFreqDig=digitString.charAt(i);
		}
		}

		
		return Integer.parseInt(mostFreqDig.toString());
	}
	static int occurence(char alfa,String digitString) {
		int occ=0;
		for(int i=0;i<digitString.length();i++) {
			if(alfa==digitString.charAt(i))
				occ++;
		}
		return occ;
	
    }
}
