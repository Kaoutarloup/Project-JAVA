package phoneshop;

public class PhoneShop {

	 /**
	  * variable instance
	  */
	    private String owner;
	    private int phoneStock;
	    private int phoneCaseStock;
	    
	    /**
	     * 
	     * @param owner
	     */

	    public PhoneShop(String owner){
	        this.owner = owner;

	    }
	    
	    /**
	     * 
	     * @return 
	     */

	    public String getOwner(){
	        return this.owner;
	    }
	    
	    /**
	     * 
	     * @return phoneStock
	     */

	    public int getPhoneStock(){
	        return this.phoneStock;
	    }
	    
	    /**
	     * 
	     * @return PhonecaseStock
	     */

	    public int getPhonecaseStock(){
	        return this.phoneCaseStock;
	    }
	    
	    
	    /**
	     * 
	     * @param number void fillStockCases
	     */



	    public void fillStockCases(int number){
	        this.phoneCaseStock += number;

	    }
	    
	    /**
	     * 
	     * @param number void FillStockPhones
	     */

	    public void fillStockPhones(int number){
	        this.phoneStock += number;

	    }
	    
	    
	    /**
	     * 
	     * @return NOK
	     */

	    public String phoneSold(){
	        if(this.phoneStock > 0){
	            this.phoneStock--;
	            return "OK";
	        }
	        return "NOK";
	    }

	    
	    
	    /**
	     * 
	     * @return NOK
	     */
	    public String caseSold(){
	        if(this.phoneCaseStock>0){
	            this.phoneCaseStock--;
	            return "OK";
	        }
	        return "NOK";
	    }
	

	

}
