@file:JvmName("LoneSum")
package logic

// TODO Implement the function
fun loneSum(values: IntArray): Int = 0
