/*
 * Project and Training 1 - Computer Science, Berner Fachhochschule
 */

@file:JvmName("RationalCalculator")
package math
