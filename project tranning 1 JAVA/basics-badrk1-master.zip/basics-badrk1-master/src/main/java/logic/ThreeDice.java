package logic;

public class ThreeDice {

    public static int getNbrOfCombinations(int sum) {
    	int possibilities=0;
		for(int red=1;red<7;red++)
			for(int blue=1;blue<7;blue++)
				for(int green=1;green<7;green++)
					if(green+red+blue==sum)
						possibilities++;
		return possibilities;

	}
}
