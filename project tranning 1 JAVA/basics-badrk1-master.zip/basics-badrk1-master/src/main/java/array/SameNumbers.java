package array;

public class SameNumbers {

    public static boolean sameNumbers(int[] values1, int[] values2) {
    	
    	boolean test=true;



		if(values1.length==0 && values2.length>0 ||values2.length==0 && values1.length>0)
			test=false;



		else if(values1.length>0&&values2.length>0)
		{
			for(int i=0;i<values1.length;i++)
				if(nbOcc(values1[i],values2)<1)
					test=false;
			for(int i=0;i<values2.length;i++)
				if(nbOcc(values2[i],values1)<1)
					test=false;		


		}
		return test;
	}
	static int nbOcc(int value , int values[]) {
		int occ=0;
		for(int i=0;i<values.length;i++)
			if(value==values[i])
				occ++;

		return occ;
	}
    }

