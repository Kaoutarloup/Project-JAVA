package fridge

// TODO Implement the class Fridge