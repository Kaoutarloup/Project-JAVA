package acl.access.resource;


import java.util.ArrayList;

public class Directory extends Resource {
    private ArrayList<Resource> children;
    
    /**
     * 
     * @param name
     */

    public Directory(String name){
        super(name);
        children = new ArrayList<>();

    }
     /**
      * 
      * @param resource
      */

    public void add(Resource resource){
        resource.setParent(this);
        this.children.add(resource);

    }


    @Override
    public String getContent(){
        if(this.children.equals(null))
                return super.getName();
        String str = "";
        for(Resource res: children){
            str += res.getName() + "\n";
        }
        return str;
    }


}
