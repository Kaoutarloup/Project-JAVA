@file:JvmName("CountDogs")
package string

// TODO Implement the function
fun countDogs(input:String): Int = 0
