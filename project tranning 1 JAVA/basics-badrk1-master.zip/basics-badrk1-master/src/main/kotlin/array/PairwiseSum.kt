@file:JvmName("PairwiseSum")

package array

fun pairwiseSum(values: IntArray): IntArray {
    // TODO Implement the function
    return intArrayOf()
}

