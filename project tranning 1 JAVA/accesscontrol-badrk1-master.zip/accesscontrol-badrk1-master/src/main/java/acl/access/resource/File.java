package acl.access.resource;

public class File extends Resource {
    String content;
    String name;


    public File(String name, String content){
        super(name);
        this.content = content;

    }
    /**
     * String get method getContent()
     */

    public String getContent() {
        return this.content;
    }
}
