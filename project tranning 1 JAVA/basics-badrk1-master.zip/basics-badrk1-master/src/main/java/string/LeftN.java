package string;

public class LeftN {

    public static String leftN(String str, int n) {
    	String rotated="";


		if(str.length()==1||str.length()<n)
			rotated=str;



		else if(str.length()>1 )
		{
			String aux=str.substring(0,n);
			rotated=str.substring(n)+aux;
		}



		return rotated;
	}
}
