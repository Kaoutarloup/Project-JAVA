package string;

public class CountDogs {

    public static int countDogs(String input) {
    	int occ=0;


		input.toLowerCase();

		System.out.println(input);
		while(findpos(input)!=input.length())
		{ 	
			occ++;
			input=input.substring(findpos(input)+2);
		}
		return occ;
	}
	public static int findpos(String input) {



		int mypos=input.length();
		String []tmp= {"dog","dig","dag","dug","deg"};



		for(int i=0;i<tmp.length;i++) {
			{   
				if (input.indexOf(tmp[i])<=mypos && input.indexOf(tmp[i])!=-1)
				{   
					mypos=input.indexOf(tmp[i]);
				}
			}
		}
		return mypos;
	}


}
