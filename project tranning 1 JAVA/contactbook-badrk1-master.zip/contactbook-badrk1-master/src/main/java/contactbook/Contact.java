package contactbook;

public class Contact {

	// The private instance variables
	
	 private String name;
	    private String email;
	    private String phoneNumber;

	    public Contact(String name, String email, String phoneNumber){
	        this.name = name;
	        this.setEmail(email);
	        this.setPhoneNumber(phoneNumber);

	    }
	    
	    /**
	     * 
	     * @return Getter et setter des attributs
	     */
	   
	    public String getName(){
	        return name;
	    }


		public String getEmail() {
			return email;
		}


		public void setEmail(String email) {
			this.email = email;
		}


		public String getPhoneNumber() {
			return phoneNumber;
		}


		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}

	
}


