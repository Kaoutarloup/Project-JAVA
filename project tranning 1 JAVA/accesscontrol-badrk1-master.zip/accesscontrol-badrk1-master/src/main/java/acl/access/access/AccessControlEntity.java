package acl.access.access;

import acl.access.user.User;

public class AccessControlEntity  {
	
	/**
	 * 
	 */

    private User principal;
    private AccessRight readPrivilege;
    
    /**
     * 
     * @param principal
     * @param readPrivilege
     */

    public AccessControlEntity(User principal, AccessRight readPrivilege){
        this.principal = principal;
        this.readPrivilege = readPrivilege;
    }

    /**
     * 
     * @return User getPrincipal()
     */
    public User getPrincipal() {
        return this.principal;
    }
    
    /**
     * 
     * @return AccessRight getAccessRight()
     */

    public AccessRight getAccessRight() {
        return this.readPrivilege;
    }
}
