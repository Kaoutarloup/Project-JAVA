package logic;

public class LoneSum {

    public static int loneSum(int[] values) {
    	int sum=0;
		for(int i=0;i<values.length;i++)
		{
			if(occurence(values[i],values)<2)
				sum+=values[i];
		}
		return sum;
	}
	private static int occurence(int alfa,int []values) {
		int occ=0;
		for(int i=0;i<values.length;i++) {
			if(alfa==values[i])
				occ++;
		}
		return occ;
	}

}
