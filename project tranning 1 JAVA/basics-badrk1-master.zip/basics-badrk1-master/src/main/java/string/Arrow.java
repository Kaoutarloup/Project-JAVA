package string;

public class Arrow {

    public static String arrow(int length, boolean doubleEnded, boolean doubleLine) {
    	String myArrow="";
		if(length<0) {
			if(doubleEnded) {
				myArrow+="<<";
			}
			else
			{
				myArrow+="<";
			}
			if(doubleLine) {
				myArrow+=arrowArc("=",-length);
			}
			else
			{
				myArrow+=arrowArc("-",-length);
			}

		}
		else if(length>0){
			if(doubleLine) {
				myArrow+=arrowArc("=",length);
			}
			else
			{
				myArrow+=arrowArc("-",length);
			}
			if(doubleEnded) {
				myArrow+=">>";
			}
			else
			{
				myArrow+=">";
			}

		}

		return myArrow;
	}
	public static String arrowArc(String tmp,int a) {
		String str="";
		for(int i=0;i<a;i++)
		{
			str+=tmp  ; 
		}
		return str;
	}

}
