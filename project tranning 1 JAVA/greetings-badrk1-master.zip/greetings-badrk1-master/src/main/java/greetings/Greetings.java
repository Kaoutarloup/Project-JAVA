package greetings;
import java.util.Scanner;


public class Greetings {
	

	public static String  getGreeting(String city) {
		
		// int myCountry = 0;
				String greeting = "";

				switch (city.toLowerCase()) {
				case "berlin":
				case "bern":
					greeting = "Guten Tag!";
					break;

				case "london":
					greeting = "Hello!";
					break;

				case "boston":
					greeting = "Hello!";
					break;

				case "paris":
					greeting = "Bonjour!";
					break;

				case "milano":
					greeting = "Ciao!";
					break;

				case "madrid":
					greeting = "Hola!";
					break;

				default:
					greeting = "City not found!";
					break;

				}

				return greeting;

			}
      
			
	
	
	   
	
	
	   
	    




	
	
	
  public static void main(String[] args) {
	  
	  Scanner scanner = new Scanner(System.in);
	  System.out.println("Enter a city: ");
	  String city = scanner.nextLine();
	  System.out.println(getGreeting(city));
	  scanner.close();
	  

  }
}

