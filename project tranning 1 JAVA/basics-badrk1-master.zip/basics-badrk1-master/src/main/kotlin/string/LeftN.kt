@file:JvmName("LeftN")
package string

// TODO Implement the function
public fun leftN(str: String, n: Int): String = ""

