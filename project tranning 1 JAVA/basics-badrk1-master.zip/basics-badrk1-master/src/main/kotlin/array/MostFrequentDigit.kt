@file:JvmName("MostFrequentDigit")

package array

fun getMostFrequentDigit(digitString: String): Int {
    // TODO Implement the function
    return 0
}
