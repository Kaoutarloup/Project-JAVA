package acl.access.access;

public enum AccessRight {
    UNSPECIFIED, GRANTED, DENIED
}
