package acl.access.user;

public class User {
	
	/**
	 * 
	 */

    private String name;
    
    /**
     * 
     * @param user name
     */

    public User(String name){
        this.name = name;
    }

}
