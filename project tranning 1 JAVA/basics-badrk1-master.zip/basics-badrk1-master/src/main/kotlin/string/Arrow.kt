@file:JvmName("Arrow")

package string

// TODO Implement the function
fun arrow(length: Int, doubleEnded: Boolean, doubleLine: Boolean): String = ""
