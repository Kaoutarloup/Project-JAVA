@file:JvmName("ThreeDice")
package logic

// TODO Implement the function
fun getNbrOfCombinations(sum: Int): Int = 0
