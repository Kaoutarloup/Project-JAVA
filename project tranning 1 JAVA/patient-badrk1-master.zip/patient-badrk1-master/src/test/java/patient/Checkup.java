package patient;

public class Checkup {

	/**
	 * instance variable
	 */
	    int height;
	    double weight;
	    double temperature;
	    boolean vaccsOk;

        /**
         * 
         * @param height
         * @param weight
         * @param temperature
         * @param vaccsOk
         */

	    public Checkup(int height, double weight, double temperature, boolean vaccsOk){
	        this.height = height;
	        this.weight = weight;
	        this.temperature = temperature;
	        this.vaccsOk = vaccsOk; 

	    }
	    
	    /**
	     * 
	     * @return height
	     */
	    public int getHeight(){
	        return height;
	    }

	    /**
	     * 
	     * @return weight
	     */
	    public double getWeight(){
	        return weight;
	    }

	    /**
	     * 
	     * @return temperature
	     */
	
	    public double getTemperature(){
	        return temperature;
	    }

	    
	    /**
	     * 
	     * @return vaccOk
	     */
	    public boolean getVaccsOk(){
	        return vaccsOk;
	    }


}
