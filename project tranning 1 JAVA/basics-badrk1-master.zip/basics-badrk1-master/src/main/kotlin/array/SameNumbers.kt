@file:JvmName("SameNumbers")

package array

fun sameNumbers(values1: IntArray, values2: IntArray): Boolean {
    // TODO Implement the function
    return false
}

