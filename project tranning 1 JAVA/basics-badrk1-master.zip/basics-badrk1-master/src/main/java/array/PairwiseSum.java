package array;

public class PairwiseSum {

    public static int[] pairwiseSum(int[] values) {
      
    	int []mySum=new int[] {};

		
		if(values.length>1)
		{  

			mySum=new int[values.length-1];
			for(int i=0;i<values.length-1;i++) {

				mySum[i]=values[i]+values[i+1];
			}
		}
		return mySum;
	}
    }

